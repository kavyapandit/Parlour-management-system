<!--Navigation-->
<nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top ">
    <div class="container-fluid">
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <div class=" text-center">
        <h1 class="mb-1" style="font-family:Lucida Handwriting;font-size:30px;text-shadow: 2px 2px #6c94b0;"><a href="index.php" style="text-decorations:none; color:inherit;">Diya</h1>
        <h4 class="" style="font-family:Lucida Sans;font-size:15px;">Women's Beauty Parlour</h4></div>
        <ul class="navbar-nav ml-auto ">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="package.php">Package</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="sc.php">Service</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="course.php">Course </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="product.php">products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="blog.php">Blogs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="feedback.php">Feedback</a>
          </li>
          <form class="form-inline">
          <a href="sc.php" class="btn navbar navbar-light" style="background-color:#6c94b0;" type="button">BOOK NOW</a>
          </form>
         </ul>
      </div>
    </div>
</nav>
  <!--Navigation-->