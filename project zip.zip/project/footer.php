 <!-- Footer -->
 <footer id="footer" class="footer-1">
    <div class="main-footer widgets-dark typo-light mt-3">
      <div class="container">
        <div class="row">
          
          <div class="col-xs-12 col-sm-6 col-md-3">
            <div class="widget no-box">
              <h5 class="widget-title">Quick Links<span></span></h5>
              <ul>
                <li><a href="index.php" style="color:#000000;">Home</a></li>
                <li><a href="index.php" style="color:#000000;">About</a></li>
                <li><a href="sc.php" style="color:#000000;"> Services</a></li>
                <li><a href="contact.php" style="color:#000000;">Contact us</a></li>
              </ul>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-3">
            <div class="widget no-box">
                <h5 class="widget-title">Follow us on<span></span></h5>
                <div class="col-lg-4 main-social-footer-29">
                  <a href="https://api.whatsapp.com/send?phone=9449470297" class="whatsapp"><span class="fa-brands fa-whatsapp"></span></a>
                  <a href="#facebook" class="facebook"><span class="fa-brands fa-facebook"></span></a>
                  <a href="#https://instagram.com/diya_beauty_saloon?igshid=YmMyMTA2M2Y=" class="instagram"><span class="fa-brands fa-instagram"></span></a>
                </div>
            </div>
          </div>
          <br>
          <br>
          <div class="col-xs-12 col-sm-6 col-md-3">
            <div class="widget no-box">
              <h5 class="widget-title">Contact Us<span></span></h5>
                <ul>
                  <li><span class="fa-solid fa-location-dot"></span> Kodialbail,Mangaluru</li><br>
                  <li><span class="fa-solid fa-phone"></span> 9449470297</li><br>
                  <li><span class="fa-solid fa-envelope"></span>diyaparlour@gmail.com
                </ul>
            </div>
          </div>
          <div class="col-xs-10 col-sm-5 col-md-3">
            <div class="widget subscribe no-box">
              <h5 class="widget-title">Locate us<span></span></h5>
                <!--Google map-->
                  <div id="map-container-google-1" class="map-container" style="height:900%; width:280%;">
                    <iframe src="https://maps.google.com/maps?q=kodialbail&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"
                      style="border:0" allowfullscreen></iframe>
                  </div>
                <!--Google Maps-->
            </div>
          </div>
        </div>
      </div>
      <div class="footer-copyright">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center">
              <p class="fs-5">Copyright © 2023. All rights reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer -->